package com.example.translator

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.RadioGroup
import com.google.mlkit.nl.translate.TranslateLanguage

// TODO: Rename parameter arguments, choose names that match
// the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
private const val ARG_PARAM1 = "param1"
private const val ARG_PARAM2 = "param2"

/**
 * A simple [Fragment] subclass.
 * Use the [Fragment_1.newInstance] factory method to
 * create an instance of this fragment.
 */
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
//import kotlinx.android.synthetic.main.fragment_1.*

class Fragment_1 : Fragment() {

    private lateinit var viewModel: TranslationViewModel

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        return inflater.inflate(R.layout.fragment_1, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        viewModel = ViewModelProvider(requireActivity()).get(TranslationViewModel::class.java)

        editText.addTextChangedListener { editable ->
            val sourceLang = getSourceLanguage()
            val targetLang = getTargetLanguage()
            viewModel.translate(editable.toString(), sourceLang, targetLang)
        }
    }

    private fun getSourceLanguage(): String {
        return when (view?.findViewById<RadioGroup>(R.id.sourceLanguageGroup)?.checkedRadioButtonId) {
            R.id.englishSource -> TranslateLanguage.ENGLISH
            R.id.spanishSource -> TranslateLanguage.SPANISH
            R.id.germanSource -> TranslateLanguage.GERMAN
            else -> TranslateLanguage.ENGLISH // default to English
        }
    }

    private fun getTargetLanguage(): String {
        return when (view?.findViewById<RadioGroup>(R.id.targetLanguageGroup)?.checkedRadioButtonId) {
            R.id.englishTarget -> TranslateLanguage.ENGLISH
            R.id.spanishTarget -> TranslateLanguage.SPANISH
            R.id.germanTarget -> TranslateLanguage.GERMAN
            else -> TranslateLanguage.ENGLISH // default to English
        }
    }
}
