package com.example.translator

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

import androidx.activity.viewModels
import androidx.lifecycle.Observer
import com.google.mlkit.nl.translate.TranslateLanguage
import kotlinx.android.synthetic.main.activity_main.*

class MainActivity : AppCompatActivity() {

    private val viewModel: TranslationViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // Observe the translatedText from the ViewModel
        viewModel.translatedText.observe(this, Observer { text ->
            translationView.text = text
        })

        // Update translation when a radio button changes
        sourceLanguageGroup.setOnCheckedChangeListener { _, _ ->
            val inputText = editText.text.toString()
            viewModel.translate(inputText, getSourceLanguage(), getTargetLanguage())
        }

        targetLanguageGroup.setOnCheckedChangeListener { _, _ ->
            val inputText = editText.text.toString()
            viewModel.translate(inputText, getSourceLanguage(), getTargetLanguage())
        }
    }

    private fun getSourceLanguage(): String {
        return when (sourceLanguageGroup.checkedRadioButtonId) {
            R.id.englishSource -> TranslateLanguage.ENGLISH
            R.id.spanishSource -> TranslateLanguage.SPANISH
            R.id.germanSource -> TranslateLanguage.GERMAN
            else -> TranslateLanguage.ENGLISH // default to English
        }
    }

    private fun getTargetLanguage(): String {
        return when (targetLanguageGroup.checkedRadioButtonId) {
            R.id.englishTarget -> TranslateLanguage.ENGLISH
            R.id.spanishTarget -> TranslateLanguage.SPANISH
            R.id.germanTarget -> TranslateLanguage.GERMAN
            else -> TranslateLanguage.ENGLISH // default to English
        }
    }
}
