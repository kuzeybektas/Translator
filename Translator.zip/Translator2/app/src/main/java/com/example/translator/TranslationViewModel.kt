package com.example.translator

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.google.mlkit.nl.translate.Translation
import com.google.mlkit.nl.translate.TranslatorOptions

class TranslationViewModel : ViewModel() {

    private val _translatedText = MutableLiveData<String>()
    val translatedText: LiveData<String> get() = _translatedText

    fun translate(inputText: String, sourceLang: String, targetLang: String) {
        val options = TranslatorOptions.Builder()
            .setSourceLanguage(sourceLang)
            .setTargetLanguage(targetLang)
            .build()

        val translator = Translation.getClient(options)

        translator.translate(inputText)
            .addOnSuccessListener { translatedText ->
                _translatedText.postValue(translatedText)
            }
            .addOnFailureListener { exception ->
                // Handle translation error
                _translatedText.postValue("Error: ${exception.message}")
            }
    }
}

